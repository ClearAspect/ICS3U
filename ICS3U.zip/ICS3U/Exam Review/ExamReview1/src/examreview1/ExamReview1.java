/*

*/
package examreview1;

import javax.swing.JOptionPane;

/**
 *
 * @author romas6904
 */
public class ExamReview1 {
    
    public static String graph(int pop, int total) {
        double percent = (double)pop/(double)total *100;
        String bar = "";
        
        for (int i = 0; i < (int)percent; i++) {
            bar += "*";
        }
        return bar;
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[] cityName = new String[5];
        int[] cityPop = new int[5];
        int totalPop = 0;
        String bar = "";
        
        for (int i = 0; i < 5; i++) {
            cityName[i] = JOptionPane.showInputDialog("Enter a city name ("+(i+1)+"/5)");
            cityPop[i] = Integer.parseInt(JOptionPane.showInputDialog("Enter the population ("+(i+1)+"/5)"));
            totalPop += cityPop[i];
        }
        
        for (int i = 0; i < 5; i++) {
            bar = graph(cityPop[i], totalPop);
            System.out.println(cityName[i]+bar);
            
        }
        
        
    }
    
}
