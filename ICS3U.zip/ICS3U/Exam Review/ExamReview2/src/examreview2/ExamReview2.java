/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examreview2;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author romas6904
 */
public class ExamReview2 {
    
    public static String graph(int percent) {
        String bar = "";
        
        for (int i = 0; i < (int)percent; i++) {
            bar += "*";
        }
        return bar;
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DecimalFormat number = new DecimalFormat("#,##0.0");
        String[] cityName = new String[5];
        int[] cityPop = new int[5];
        double[] cityPercent = new double[5];
        int totalPop = 0;
        String bar = "";

        try {
            File f = new File("src/examreview2/Cities.txt");
            Scanner s = new Scanner(f);
            for (int i = 0; i < 5; i++) {
                cityName[i] = s.nextLine();
                cityPop[i] = Integer.parseInt(s.nextLine());
                totalPop += cityPop[i];
            }
            for (int i = 0; i < 5; i++) {
                cityPercent[i] = (double)cityPop[i]/(double)totalPop *100;
                bar = graph((int)cityPercent[i]);
                System.out.println(cityName[i] + bar + number.format(cityPercent[i])+"%");
            }

        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e);
        }

    }
    
}
