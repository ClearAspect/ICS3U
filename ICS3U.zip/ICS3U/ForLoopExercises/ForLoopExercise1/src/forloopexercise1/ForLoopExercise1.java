/*
Roan Mason
2/24/2022

Print the phrase “I am the best!” 700,000 times
*/
package forloopexercise1;

public class ForLoopExercise1 {

    public static void main(String[] args) {
        //print I am the best 700,000 times
        for (int i = 1; i <= 700000; i++){
            System.out.println("I am the best!");
        }
        
    }
    
}
